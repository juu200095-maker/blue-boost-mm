BLUE BOOST MM — FREE PWA DEMO
================================

Included files:
- index.html: the demo website
- manifest.webmanifest: installable web-app settings
- sw.js: basic offline cache
- icon.svg: app icon

IMPORTANT LIMITATIONS
- This is a front-end demo only. Login/password and demo orders are stored in the current browser; this is NOT secure for real users.
- No real KPay, WavePay, AYA Pay transactions are processed.
- Orders do not deliver real likes, views, or followers.
- Before launching publicly, replace demo authentication with a secure server/database, add admin permissions, and use authorized payment/service integrations.
- For Android APK packaging, publish the website over HTTPS first, then use a trusted PWA-to-Android packaging service. Review permissions and signing before installing or distributing an APK.

FREE HOSTING STEPS (GitHub Pages)
1. Create/sign in to a GitHub account.
2. Create a new PUBLIC repository, e.g. blue-boost-mm.
3. Upload all four files from this folder to the repository root.
4. In repository Settings > Pages, choose deploy from a branch, select main and /(root), then Save.
5. Wait for the published HTTPS address to appear in Settings > Pages.
6. Open the HTTPS website on Android Chrome. Use the browser menu and choose “Install app” or “Add to Home screen” if available.

APK NEXT STEP
Once the HTTPS website is live, use PWABuilder (https://www.pwabuilder.com/) to check the PWA and explore Android packaging. Follow its current instructions. An APK may require signing and may not be accepted by every Android device without confirming installation.

This package is a starting point, not a production-ready service.
